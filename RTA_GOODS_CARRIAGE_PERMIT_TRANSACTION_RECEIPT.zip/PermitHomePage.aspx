﻿<%@ Page Title="" Language="C#" MasterPageFile="JHTRANSPORT.master" AutoEventWireup="true" CodeFile="PermitHomePage.aspx.cs" Inherits="PermitHomePage" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="Server">
   <%-- <link href="assets/global/plugins/datatables/datatables.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.css" rel="stylesheet" type="text/css" />
    <link href="assets/global/plugins/bootstrap-datepicker/css/bootstrap-datepicker3.min.css" rel="stylesheet" type="text/css" />
  --%>  <link href="assets/global/plugins/jstree/dist/themes/default/style.min.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
        div.alert-success{ text-align:center !important;color:black !important;}
        div.alert-success:hover{ border-color:gold !important; color:black !important; background-color:yellow !important}
        a:hover{ text-decoration:none !important}
        .side-menu {
  /*position: fixed;
  width: 300px;
  height: 100%;
  background-color: #f8f8f8;
  border-right: 1px solid #e7e7e7;*/
}
.side-menu .navbar {
  border: none;
  
}
.side-menu .navbar-header {
  width: 100%;
  border-bottom: 1px solid #e7e7e7;
   
}
.side-menu .navbar-cav .active a {
  /*background-color: transparent;*/
  margin-right: -1px;
  border-right: 5px solid #e7e7e7;
}
.side-menu .navbar-cav li {
  display: block;
  width: 100%;
  border-bottom: 1px solid #e7e7e7;
  /*background-color: #FFF;*/
}
.side-menu .navbar-cav li a {
  padding: 15px;
}
.side-menu .navbar-cav li a .glyphicon {
  padding-right: 10px;
}
.side-menu #dropdown {
  border: 0;
  margin-bottom: 0;
  border-radius: 0;
  /*background-color: #FFF;*/
  box-shadow: none;
}
.side-menu #dropdown .caret {
  float: right;
  margin: 9px 5px 0;
}
.side-menu #dropdown .indicator {
  float: right;
}
.side-menu #dropdown > a {
  border-bottom: 1px solid #e7e7e7;
}
.side-menu #dropdown .panel-body {
  padding: 0;
  /*background-color: #f3f3f3;*/
}
.side-menu #dropdown .panel-body .navbar-cav {
  width: 100%;
}
.side-menu #dropdown .panel-body .navbar-cav li {
  padding-left: 15px;
  border-bottom: 1px solid #e7e7e7;
}
.side-menu #dropdown .panel-body .navbar-cav li:last-child {
  border-bottom: none;
}
.side-menu #dropdown .panel-body .panel > a {
  margin-left: -20px;
  padding-left: 35px;
}
.side-menu #dropdown .panel-body .panel-body {
  margin-left: -15px;
}
.side-menu #dropdown .panel-body .panel-body li {
  padding-left: 30px;
}
.side-menu #dropdown .panel-body .panel-body li:last-child {
  border-bottom: 1px solid #e7e7e7;
}

    </style>
   
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="Server">
    <div class="page-container">
        <div class="page-content-wrapper">
            <div class="page-content">
                <div class="container">
                    <ul class="page-breadcrumb breadcrumb">
                       
                         <%--<li>
                            <a href="PermitHomePage.aspx">Home</a>
                            <%--<i class="fa fa-circle"></i>
                     </li>--%>
                       
                    </ul>
                    <div class="page-content-inner">
                        <div class="row">

                            <div class="col-md-4">
                                    <div class="portlet light ">
                                        <div class="portlet-title">
                                            <div class="caption">
                                                <i class="icon-social-dribbble font-green-sharp"></i>
                                                <span class="caption-subject font-green-sharp bold uppercase">Online Permit System</span>
                                            </div>
                                           
                                        </div>
                                        <div class="portlet-body">
                                             <div class="side-menu">
                                            <div class="side-menu-container">
                                                <ul class="nav navbar-cav" id="phMenu" runat="server">
                                                  
                                                   
                                                </ul>
                                            </div> </div>
                                        </div>
                                    </div>
                                </div>
                           <div class="col-md-8">
                         

                                     <div class="portlet light ">
                                        <div class="portlet-title">
                                            <div class="caption">
                                                <i class="icon-social-dribbble font-green-sharp"></i>
                                                <span class="caption-subject font-green-sharp bold uppercase">Overview of online apply and issue of permit/counter signature</span>
                                            </div>
                                           
                                        </div>
                                        <div class="portlet-body">
                                            <img src="assets/apps/img/process.png"  />
                                            <br />
                                            <p><b>In case of any technical glitches, please write in to us at spermitjhr@gmail.com or call us at 0651-2401699</b></p>
                                        </div>
                                    </div>
                                     <div class="portlet light ">
                                        <div class="portlet-title">
                                            <div class="caption">
                                                <i class="icon-social-dribbble font-green-sharp"></i>
                                                <span class="caption-subject font-green-sharp bold uppercase">Important things required to apply for online permit</span>
                                            </div>
                                           
                                        </div>
                                        <div class="portlet-body">
                                            <ul class="caption-subject font-black-sharp bold ">
                                                <li>Valid Mobile Number</li>
                                                <li>Scanned copy of Registration Certificate (RC) for Vehicle (PDF format)</li>
                                                <li>Scanned copy of valid insurance certificate of latest vehicle (PDF format) </li>
                                                <li>Scanned copy of valid pollution certificate (PDF format)</li>
                                                <li>Scanned copy of valid vehicle fitness certificate (PDF format)</li>
                                                <li>Other supporting documents/ information (PDF format)</li>
                                                <li>For any query please contact us at 0651-2401699</li>

                                            </ul>
                                        </div>
                                    </div>
                           </div>
                        </div>
                        <%--<div class="row">
                            <div class="col-md-12">
                                <div class="portlet light portlet-fit">
                                    <div class="portlet-title">
                                        <div class="caption">
                                            <i class="icon-settings font-red"></i>
                                            <span class="caption-subject font-red sbold uppercase">Online Permit System</span>
                                        </div>
                                    </div>
                                    <div class="portlet-body">
                                        <form id="FormID1" runat="server" class="form-horizontal" autocomplete="off">
                                            <div class="row">
                                                <div class="col-md-2"></div>
                                                <div class="col-md-3">
                                                    <asp:HyperLink  ID="HyperLink1" ToolTip="STA" runat="server">
                                                   
                                                    
                                                        <div class="alert alert-success">
                                                            <strong>STA</strong>
                                                   
                                                        
                                                             </div>
                                                   
                                                   </asp:HyperLink>
                                                </div>
                                                <div class="col-md-2"></div>
                                                <div class="col-md-3">
                                                    <asp:HyperLink ID="HyperLink2" ToolTip="RTA" runat="server">
                                                    
                                                        <div class="alert alert-success">
                                                            <strong>RTA</strong>
                                                   
                                                        
                                                             </div>
                                                   
                                                    </asp:HyperLink>
                                                </div>
                                                <div class="col-md-2"></div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-2"></div>
                                                <div class="col-md-3">

                                         <a href='STA_COUNTER_SIGNATURE_UPLOAD.aspx' title='Upload Counter Signature'>
                                             <div class='alert alert-success'><strong> STA Permit Counter Signature Upload</strong> </div></a>
                                            </div>
                                                <div class="col-md-2"></div>
                                                <div class="col-md-3">
                                                    <a href='STA_OBJECTION_LIST.aspx' title='Upload Counter Signature'>
                                             <div class='alert alert-success'><strong> List of Published Application (STA)</strong> </div></a>
                                         
                                                </div>
                                                <div class="col-md-2"></div>
                                                 </div>
                                               <div class="row">
                                                <div class="col-md-2"></div>
                                                <div class="col-md-3">

                                         <a href='STA_COUNTER_SIGNATURE_TAX_PAY.aspx' title='STA Counter Signature Tax Payment'>
                                             <div class='alert alert-success'><strong> STA Counter Signature Tax Payment</strong> </div></a>
                                            </div>
                                                <div class="col-md-2"></div>
                                                <div class="col-md-3">
                                                    
                                                </div>
                                                <div class="col-md-2"></div>
                                                 </div>
                                       </form>
                                    </div>

                                </div>
                            </div>
                        </div>--%>
                    </div>
                </div>
            </div>
        </div>
    </div>

</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="ContentPlaceHolder2" runat="Server">
       <script src="assets/global/plugins/jstree/dist/jstree.min.js" type="text/javascript"></script>
       <script src="assets/pages/scripts/ui-tree.min.js" type="text/javascript"></script>
     
<%--    <script src="assets/global/scripts/datatable.js" type="text/javascript"></script>
    <script src="assets/global/plugins/datatables/datatables.js" type="text/javascript"></script>
    <script src="assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
    <script src="assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js" type="text/javascript"></script>--%>
   <script type="text/javascript">
    $(function () {
    $('.navbar-toggle').click(function () {
        $('.navbar-cav').toggleClass('slide-in');
        $('.side-body').toggleClass('body-slide-in');
        $('#search').removeClass('in').addClass('collapse').slideUp(200);

        /// uncomment code for absolute positioning tweek see top comment in css
        //$('.absolute-wrapper').toggleClass('slide-in');
        
    });
   
   // Remove menu for searching
   $('#search-trigger').click(function () {
        $('.navbar-cav').removeClass('slide-in');
        $('.side-body').removeClass('body-slide-in');

        /// uncomment code for absolute positioning tweek see top comment in css
        //$('.absolute-wrapper').removeClass('slide-in');

    });
    });
       </script>
</asp:Content>

