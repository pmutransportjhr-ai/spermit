﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using SoftEra.JHT.Infrastructure;
using System.Configuration;
using System.Web.Script.Serialization;
using System.Transactions;
using Newtonsoft.Json;
using System.Text;
using System.Web.UI.HtmlControls;



public partial class PermitHomePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //string q = HttpUtility.UrlEncode(CryptorEngine.Encrypt("TYPE=STA", true));
            //string q1 = HttpUtility.UrlEncode(CryptorEngine.Encrypt("TYPE=RTA", true));
            //HyperLink1.NavigateUrl = "PermitOptions.aspx?q=" + q;
            //HyperLink2.NavigateUrl = "PermitOptions.aspx?q=" + q1;

            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@MODE", "MENULIST");

            DataSet dsMenu = SQLHelper.ExecuteDataset(SQLHelper.GetConnString(), CommandType.StoredProcedure, "SP_GET_MENU_ITEMS_CLIENT", parameters);
            DataTable dtMnu = new DataTable();
            dtMnu = dsMenu.Tables[0];
            BindMenu(dtMnu);

        }}
        
        protected void BindMenu(DataTable dtMenu)
    {
        DataRow[] TopMenu = dtMenu.Select("SUB_MENU='N'");
        String sMenu = "";

        foreach (DataRow drTopMenu in TopMenu)
        {


            
                if (Convert.ToString(drTopMenu["URL"]) == null || Convert.ToString(drTopMenu["URL"]) == "")
                {
                    sMenu += "<li>";
                    sMenu += "<a data-toggle='collapse' href='#dropdown-lvl" + Convert.ToString(drTopMenu["MENU_ID"]) +"'><span class='glyphicon glyphicon-off'></span>" + Convert.ToString(drTopMenu["MENU_ITEM"]) + "<span class='caret'></span></a>";
                }
                else
                {
                    sMenu += "<li class='panel panel-default' id='dropdown'>"; 
                    sMenu += "<a href='" + Convert.ToString(drTopMenu["URL"]) + "'>" + Convert.ToString(drTopMenu["MENU_ITEM"]) + "</a>";
                }

                DataRow[] fChldMenu = dtMenu.Select("PARENT_MENU_ID=" + Convert.ToString(drTopMenu["MENU_ID"]));
                if (fChldMenu.Length > 0)
                {
                    sMenu += "<div id='dropdown-lvl" + Convert.ToString(drTopMenu["MENU_ID"]) + "' class='panel-collapse collapse'>";
                    sMenu += "<div class='panel-body'>";
                    sMenu += "<ul class='nav navbar-cav'>";
                    foreach (DataRow drFChldMenu in fChldMenu)
                    {
                        
                            
                                DataRow[] sChldMenu = dtMenu.Select("PARENT_MENU_ID=" + Convert.ToString(drFChldMenu["MENU_ID"]));
                                
                                    sMenu += "<li >";
                                

                                if (Convert.ToString(drFChldMenu["URL"]) == null || Convert.ToString(drFChldMenu["URL"]) == "")
                                {
                                    sMenu += "<a data-toggle='collapse' href='#dropdown-lvl" + Convert.ToString(drFChldMenu["MENU_ID"]) + "'><span class='glyphicon glyphicon-off'></span>" + Convert.ToString(drFChldMenu["MENU_ITEM"]) + "<span class='caret'></span></a>";
                                }
                                else
                                {

                                    sMenu += "<a href='" + Convert.ToString(drFChldMenu["URL"]) + "' >" + Convert.ToString(drFChldMenu["MENU_ITEM"]) + "</a>";

                                }

                                if (sChldMenu.Length > 0)
                                {
                                    sMenu += "<div id='dropdown-lvl" + Convert.ToString(drFChldMenu["MENU_ID"]) + "' class='panel-collapse collapse'>";
                                    sMenu += "<div class='panel-body'>";
                                    sMenu += "<ul class='nav navbar-cav'>";
                                    foreach (DataRow drSChldMenu in sChldMenu)
                                    {
                                        
                                            //sMenu += "<li class=''>";
                                            //if (Convert.ToString(drSChldMenu["URL"]) == null || Convert.ToString(drSChldMenu["URL"]) == "")
                                            //{
                                            //    sMenu += "<a href='#' >" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "</a>";
                                            //}
                                            //else
                                            //{
                                            //    sMenu += "<a href='" + Convert.ToString(drSChldMenu["URL"]) + "' >" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "</a>";
                                            //}
                                            //sMenu += "</li>";

                                        DataRow[] tChldMenu = dtMenu.Select("PARENT_MENU_ID=" + Convert.ToString(drSChldMenu["MENU_ID"]));
                                        
                                            sMenu += "<li >";
                                        

                                        if (Convert.ToString(drSChldMenu["URL"]) == null || Convert.ToString(drSChldMenu["URL"]) == "")
                                        {
                                            sMenu += "<a data-toggle='collapse' href='#dropdown-lvl" + Convert.ToString(drSChldMenu["MENU_ID"]) + "'><span class='glyphicon glyphicon-off'></span>" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "<span class='caret'></span></a>";
                                        }
                                        else
                                        {

                                            sMenu += "<a href='" + Convert.ToString(drSChldMenu["URL"]) + "' >" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "</a>";

                                        }

                                        if (tChldMenu.Length > 0)
                                        {
                                            sMenu += "<div id='dropdown-lvl" + Convert.ToString(drSChldMenu["MENU_ID"]) + "' class='panel-collapse collapse'>";
                                            sMenu += "<div class='panel-body'>";
                                            sMenu += "<ul class='nav navbar-cav'>";
                                            foreach (DataRow drTChldMenu in tChldMenu)
                                            {
                                                string q = HttpUtility.UrlEncode(CryptorEngine.Encrypt(Convert.ToString(drTChldMenu["Q_STRING"]), true));
                           
                                                sMenu += "<li class=''>";
                                                if (Convert.ToString(drTChldMenu["URL"]) == null || Convert.ToString(drTChldMenu["URL"]) == "")
                                                {
                                                    sMenu += "<a data-toggle='collapse' href='#dropdown-lvl" + Convert.ToString(drTChldMenu["MENU_ID"]) + "'><span class='glyphicon glyphicon-off'></span>" + Convert.ToString(drTChldMenu["MENU_ITEM"]) + "<span class='caret'></span></a>";
                                                }
                                                else
                                                {
                                                    sMenu += "<a href='" + Convert.ToString(drTChldMenu["URL"]) + "?q=" + q + "' >" + Convert.ToString(drTChldMenu["MENU_ITEM"]) + "</a>";
                                                }
                                                sMenu += "</li>";

                                            }
                                            sMenu += "</ul>";
                                            sMenu += "</div>";
                                            sMenu += "</div>";
                                        }

                                        sMenu += "</li>";


                                        
                                    }
                                    sMenu += "</ul>";
                                    sMenu += "</div>";
                                    sMenu += "</div>";
                                }

                                sMenu += "</li>";
                           
                        
                    }
                    sMenu += "</ul>";
                    sMenu += "</div>";
                    sMenu += "</div>";
                }
                sMenu += "</li>";
            
        }
        phMenu.InnerHtml = sMenu;
        
    }
   
   
}