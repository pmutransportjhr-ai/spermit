﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LogOut : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ValidateSession.DeleteUserSession(Convert.ToString(Session["EMPLOYEE_ID"]), Convert.ToString(Session["USER_TYPES"]), Convert.ToString(Session["BROWSER"]));
        Session.Clear();
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }
}