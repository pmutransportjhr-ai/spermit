﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using SoftEra.JHT.Infrastructure;
using System.Text;
using System.Collections.Generic;
using System.Data;


using System.Data;

using System.Configuration;
using System.Web.Script.Serialization;

using Newtonsoft.Json;
using System.Text;


public partial class PaymentRequest : System.Web.UI.Page
{
    String DEPTID;
    String RECIEPTHEADCODE;
    String DEPOSITERNAME;
    String DEPTTRANID;
    Decimal AMOUNT;
    String DEPOSITERID;
    String PANNO;
    String ADDINFO1;
    String ADDINFO2;
    String ADDINFO3;
    String TREASCODE;
    String IFMSOFFICECODE;
    String STATUS;
    String PAYMENTSTATUSMESSAGE;
    String GRN;
    String CIN;
    String REF_NO;
    String TXN_DATE;
    String TXN_AMOUNT;
    String CHALLAN_URL;
    String PMODE;
    String ADDINFO5;


    public string enc_val { get; set; }
    
    
    protected void Page_Load(object sender, EventArgs e)
   {
        try
        {
            if (!IsPostBack)
            {
                if (string.IsNullOrEmpty(Request.QueryString["q"]))
                {
                    //ScriptManager.RegisterStartupScript(Page,this.GetType(), "ShowStatus", "javascript:alert('Record is not updated');", true);
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ShowStatus", "javascript:alert('Record is not updated');", true);

                    ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('You are not permitted to access this page');window.location ='PermitHomePage.aspx'", true);
                    return;
                }
                else
                {

                    //String Q_STRING = Convert.ToString(Request.QueryString["q"]);
                    //SqlParameter[] parameters = new SqlParameter[1];
                    //parameters[0] = new SqlParameter("@Q_STRING", Q_STRING);
                    //DataSet ds = SQLHelper.ExecuteDataset(SQLHelper.GetConnString(), CommandType.StoredProcedure, "PAYMENT_REQUEST_HISTORY_AED", parameters);

                    String DecryptedVal1 = PayGetWayResponseDTO.MakeDecryptedData(Request.QueryString["q"].ToString());
                    String[] arr1;
                    arr1 = DecryptedVal1.Split('|');

                    string DEPTID = arr1[0];
                    string RECIEPTHEADCODE = arr1[1];
                    string DEPOSITERNAME = arr1[2];
                    string DEPTTRANID = arr1[3];
                    decimal AMOUNT = Convert.ToDecimal(arr1[4]);
                    string DEPOSITERID = arr1[5];
                    string PANNO = arr1[6];
                    string ADDINFO1 = arr1[7];
                    string ADDINFO2 = arr1[8];
                    string TREASCODE = arr1[10];
                    string IFMSOFFICECODE = arr1[11];
                    string SECURITY_CODE = arr1[12];
                    SqlCommand scmd = new SqlCommand("SP_PAYMENT_TRANSACTIONS_HISTORY_AED");
                    scmd.Parameters.AddWithValue("@APP_ID", Convert.ToInt32(ADDINFO2));
                    scmd.Parameters.AddWithValue("@APPLICATION_NUMBER", DEPOSITERID);
                    scmd.Parameters.AddWithValue("@OPERATION_FOR", ADDINFO1);
                    scmd.Parameters.AddWithValue("@MODE", "CHECK_BEFORE_PAYMENT");
                    scmd.CommandType = CommandType.StoredProcedure;
                    SqlConnection con = new SqlConnection(SQLHelper.GetConnString());
                    scmd.Connection = con;
                    SqlDataAdapter da = new SqlDataAdapter(scmd);
                    DataSet ds1 = new DataSet();
                    da.Fill(ds1);
                    DataTable dt = ds1.Tables[0];

                    if (dt.Rows.Count > 0)
                    {

                        if (Convert.ToString(dt.Rows[0]["TRN_STATUS"]) == "SUCCESS")
                        {
                            ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Already Paid');window.location ='PermitHomePage.aspx';", true);
                           
                        }
                        if (Convert.ToString(dt.Rows[0]["TRN_STATUS"]) == "FAIL")
                        {

                        }
                        if (Convert.ToString(dt.Rows[0]["TRN_STATUS"]) == "BOOKED")
                        {

                            double hrsDifference = DateTime.Now.Subtract(Convert.ToDateTime(dt.Rows[0]["TRANSACTION_ON"])).Hours;
                            if (hrsDifference < 2.0)
                            {
                                //btnViewHide.Value = "0";
                               
                               ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Please pay after 2 hours.');window.location='PermitHomePage.aspx';", true);
                               return;
                            }
                            else
                            {
                                ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Please Check Payment Status.');window.location='ClientPaymentStatus.aspx';", true);
                                return;
                            }
                        }


                    }

                }

            }
        }
        catch(Exception ex)
        {
            String Message = ex.Message.ToString();
            Message = Message.Replace("\r", " ").Replace("\n", " ").Replace("'", "");
            ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('" + Message + "');window.location='PermitHomePage.aspx';", true);
            return;
        }
    }



    
}