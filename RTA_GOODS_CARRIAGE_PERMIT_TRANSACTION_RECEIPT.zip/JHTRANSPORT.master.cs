﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SoftEra.JHT.Infrastructure;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;

public partial class JHTRANSPORT : System.Web.UI.MasterPage, System.Web.SessionState.IRequiresSessionState
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlParameter[] parameters = new SqlParameter[1];
        parameters[0] = new SqlParameter("@MODE", "MENULIST");

        DataSet dsMenu = SQLHelper.ExecuteDataset(SQLHelper.GetConnString(), CommandType.StoredProcedure, "SP_GET_MENU_ITEMS_CLIENT", parameters);
        DataTable dtMnu = new DataTable();
        dtMnu = dsMenu.Tables[0];
        BindMenu(dtMnu);


    }
    protected void BindMenu(DataTable dtMenu)
    {
        DataRow[] TopMenu = dtMenu.Select("SUB_MENU='N'");
        String sMenu = "";

        foreach (DataRow drTopMenu in TopMenu)
        {
           
            
                sMenu += "<li class='menu-dropdown classic-menu-dropdown'>";
                if (Convert.ToString(drTopMenu["URL"]) == null || Convert.ToString(drTopMenu["URL"]) == "")
                {
                    sMenu += "<a href='#'>" + Convert.ToString(drTopMenu["MENU_ITEM"]) + "<span class='arrow'></span></a>";
                }
                else
                {
                    sMenu += "<a href='" + Convert.ToString(drTopMenu["URL"]) + "'>" + Convert.ToString(drTopMenu["MENU_ITEM"]) + "<span class='arrow'></span></a>";
                }

                DataRow[] fChldMenu = dtMenu.Select("PARENT_MENU_ID=" + Convert.ToString(drTopMenu["MENU_ID"]));
                if (fChldMenu.Length > 0)
                {
                    sMenu += "<ul class='dropdown-menu pull-left'>";
                    foreach (DataRow drFChldMenu in fChldMenu)
                    {
                        
                            
                                DataRow[] sChldMenu = dtMenu.Select("PARENT_MENU_ID=" + Convert.ToString(drFChldMenu["MENU_ID"]));
                                if (sChldMenu.Length > 0)
                                {
                                    sMenu += "<li class='dropdown-submenu'>";
                                }
                                else
                                {
                                    sMenu += "<li class='dropdown'>";
                                }

                                if (Convert.ToString(drFChldMenu["URL"]) == null || Convert.ToString(drFChldMenu["URL"]) == "")
                                {
                                    sMenu += "<a href='#' class='nav-link nav-toggle'>" + Convert.ToString(drFChldMenu["MENU_ITEM"]) + "</a>";
                                }
                                else
                                {

                                    sMenu += "<a href='" + Convert.ToString(drFChldMenu["URL"]) + "' class='nav-link nav-toggle'>" + Convert.ToString(drFChldMenu["MENU_ITEM"]) + "</a>";

                                }

                                if (sChldMenu.Length > 0)
                                {
                                    sMenu += "<ul class='dropdown-menu'>";
                                    foreach (DataRow drSChldMenu in sChldMenu)
                                    {
                                        
                                            //sMenu += "<li class=''>";
                                            //if (Convert.ToString(drSChldMenu["URL"]) == null || Convert.ToString(drSChldMenu["URL"]) == "")
                                            //{
                                            //    sMenu += "<a href='#' class='nav-link nav-toggle'>" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "</a>";
                                            //}
                                            //else
                                            //{
                                            //    sMenu += "<a href='" + Convert.ToString(drSChldMenu["URL"]) + "' class='nav-link nav-toggle'>" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "</a>";
                                            //}
                                            //sMenu += "</li>";

                                        DataRow[] tChldMenu = dtMenu.Select("PARENT_MENU_ID=" + Convert.ToString(drSChldMenu["MENU_ID"]));
                                        if (tChldMenu.Length > 0)
                                        {
                                            sMenu += "<li class='dropdown-submenu'>";
                                        }
                                        else
                                        {
                                            sMenu += "<li class='dropdown'>";
                                        }

                                        if (Convert.ToString(drSChldMenu["URL"]) == null || Convert.ToString(drSChldMenu["URL"]) == "")
                                        {
                                            sMenu += "<a href='#' class='nav-link nav-toggle'>" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "</a>";
                                        }
                                        else
                                        {

                                            sMenu += "<a href='" + Convert.ToString(drSChldMenu["URL"]) + "' class='nav-link nav-toggle'>" + Convert.ToString(drSChldMenu["MENU_ITEM"]) + "</a>";

                                        }

                                        if (tChldMenu.Length > 0)
                                        {
                                            sMenu += "<ul class='dropdown-menu'>";
                                            foreach (DataRow drTChldMenu in tChldMenu)
                                            {
                                                string q = HttpUtility.UrlEncode(CryptorEngine.Encrypt(Convert.ToString(drTChldMenu["Q_STRING"]), true));
                           
                                                sMenu += "<li class=''>";
                                                if (Convert.ToString(drTChldMenu["URL"]) == null || Convert.ToString(drTChldMenu["URL"]) == "")
                                                {
                                                    sMenu += "<a href='#' class='nav-link nav-toggle'>" + Convert.ToString(drTChldMenu["MENU_ITEM"]) + "</a>";
                                                }
                                                else
                                                {
                                                    sMenu += "<a href='" + Convert.ToString(drTChldMenu["URL"]) + "?q=" + q + "' class='nav-link nav-toggle'>" + Convert.ToString(drTChldMenu["MENU_ITEM"]) + "</a>";
                                                }
                                                sMenu += "</li>";

                                            }
                                            sMenu += "</ul>";
                                        }

                                        sMenu += "</li>";


                                        
                                    }
                                    sMenu += "</ul>";
                                }

                                sMenu += "</li>";
                           
                        
                    }
                    sMenu += "</ul>";
                }
                sMenu += "</li>";
            
        }

        HtmlGenericControl myMenuControl = (HtmlGenericControl)Page.Master.FindControl("ulMenu");
        if (myMenuControl != null)
        {
            myMenuControl.InnerHtml = sMenu;
        }
    }
}