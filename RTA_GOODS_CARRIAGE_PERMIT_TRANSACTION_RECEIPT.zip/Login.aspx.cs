﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Principal;
using System.Configuration;
using System.Security;
using System.Security.Principal;
using System.Globalization;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using SoftEra.JHT.Infrastructure;
using System.Transactions;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Login : System.Web.UI.Page
{
    string randumid = "", logoutPath = "";
    Random random = new Random();
  

    #region code for PreInIt event

    protected void Page_PreInit(object sender, EventArgs e)
    {
        Page.ViewStateUserKey = Session.SessionID;
        Response.Cache.SetCacheability(HttpCacheability.NoCache);
        Page.Theme = "";
    }

    #endregion 

    protected void Page_Load(object sender, EventArgs e)
    {
        
        //this.Page.ClientScript.RegisterClientScriptInclude("SCRIPT1", ResolveUrl("~/js/sha512.js"));

        if (!Page.IsPostBack)
        {

            txtLogin.Focus();
            Session["salt"] = ConfigurationManager.AppSettings["SecurityKey"] /*random.Next(59999, 199999).ToString()*/;
            //= drawString;
          //  hdnCap.Value = Convert.ToString( Session["captcha"]);
        }
    }

    protected void btnLogin_Click1(object sender, EventArgs e)
    {
        login();
    }
    public void login()
    {
        
        HttpBrowserCapabilities bc = Request.Browser;
        String LOGIN_ID = txtLogin.Text;
        String PASSWORD = txtPassword.Text.Trim();
        String TYPE = ddlType.SelectedValue;
        string Upass = hfpwd.Value;

        Session["msg"] = "";
        HttpCookie cookie = new HttpCookie("Temp");

        Session["Temp"] = random.Next(59999, 199999).ToString();
        cookie.Value = Session["Temp"].ToString();
        Response.Cookies.Add(cookie);

        String Saltval = Session["salt"].ToString();

        string Tpass = hashcodegenerate.GetSHA512(Upass + Session["salt"].ToString());
      //  String DecryptVal = DecryptHexCode.GetDecryptVal(Tpass, Session["salt"].ToString());
        
        DataSet dsUser = new DataSet();

        SqlParameter[] parameters = new SqlParameter[2];
        parameters[0] = new SqlParameter("@LOGIN_ID", LOGIN_ID);
        parameters[1] = new SqlParameter("@PASSWORD", Tpass);
        //parameters[2] = new SqlParameter("@TYPE", TYPE);

        if (TYPE == "STA")
        {
            dsUser = SQLHelper.ExecuteDataset(SQLHelper.GetConnString(), CommandType.StoredProcedure, "STA_SP_LOGIN_VALIDATE_USER", parameters);
        }
        else
        {
            dsUser = SQLHelper.ExecuteDataset(SQLHelper.GetConnString(), CommandType.StoredProcedure, "RTA_SP_LOGIN_VALIDATE_USER", parameters);
        }
        
        DataTable dtUser = new DataTable();
        
        
        dtUser = dsUser.Tables[0];

        if (dtUser.Rows.Count > 0)
        {
            Session.Clear();
            Session["EMPLOYEE_ID"] = Convert.ToString(dtUser.Rows[0]["EMPLOYEE_ID"]);
            Session["EMPLOYEE_NAME"] = Convert.ToString(dtUser.Rows[0]["EMPLOYEE_NAME"]);
            Session["EMAIL_ID"] = Convert.ToString(dtUser.Rows[0]["EMAIL_ID"]);
            Session["DEPARTMENT"] = Convert.ToString(dtUser.Rows[0]["DEPARTMENT"]);
            Session["DESIGNATION"] = Convert.ToString(dtUser.Rows[0]["DESIGNATION"]);
            Session["STATUS"] = Convert.ToString(dtUser.Rows[0]["STATUS"]);
            Session["USER_TYPE"] = Convert.ToString(dtUser.Rows[0]["USER_TYPE"]);
            Session["RTO_CODE"] = Convert.ToString(dtUser.Rows[0]["RTO_CODE"]);
            Session["RTO_NAME"] = Convert.ToString(dtUser.Rows[0]["RTO_NAME"]);
            Session["USER_LABEL"] = Convert.ToString(dtUser.Rows[0]["USER_LEVEL"]);
            Session["BROWSER"] = Convert.ToString(bc.Browser);
            Session["USER_TYPES"] = Convert.ToString(TYPE);
            
            if (Convert.ToString(dtUser.Rows[0]["USER_ROLE"]) == string.Empty)
            Session["USER_ROLE"] = "One"; //Convert.ToString(dtUser.Rows[0]["USER_ROLE"]);
            else
            Session["USER_ROLE"] = Convert.ToString(dtUser.Rows[0]["USER_ROLE"]);
            //Response.Redirect("dashboard.aspx");
            //String User_type=Convert.ToString(dtUser.Rows[0]["USER_TYPE"]);
            
            String Browser = bc.Browser;

            String MSG = ValidateSession.ValidateUserSession(Convert.ToString(dtUser.Rows[0]["EMPLOYEE_ID"]), getclientIP().ToString(), TYPE, bc.Browser);
            if (MSG == "Success")
            {

                if (TYPE == "STA")
                {
                    Response.Redirect("STA-DASHBOARD.aspx");
                }
                else if (TYPE == "RTA")
                {
                    Response.Redirect("RTA-DASHBOARD.aspx");
                }
            }
            else if (MSG == "Sorry You have already logged in with another Browser or Another System")
            {
                ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Sorry You have already logged in with another Browser or Another System');", true);
            }
            else
            {
                String Message=string.Empty;
                Message=MSG.Replace("\n","").Replace("\r","");
                ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('"+Message+"');", true);
                Session.Abandon();
                Response.Redirect("Login.aspx");
            }

        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('Sorry! Invalid Login Details');", true);
        }
    }
    protected void btnFP_Click(object sender, EventArgs e)
    {
        Response.Redirect("ForgotPassword.aspx");
    }
    public static string getclientIP()
    {
        string result = string.Empty;
        string ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (!string.IsNullOrEmpty(ip))
        {
            string[] ipRange = ip.Split(',');
            int le = ipRange.Length - 1;
            result = ipRange[0];
        }
        else
        {
            result = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        }

        return result;
    }
}